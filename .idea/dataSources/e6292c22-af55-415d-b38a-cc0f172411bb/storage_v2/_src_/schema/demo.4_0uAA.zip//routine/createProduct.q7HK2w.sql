create
    definer = root@localhost procedure createProduct(IN name varchar(50), IN price float, IN quantity int,
                                                     IN color varchar(50), IN description varchar(100),
                                                     IN category varchar(50))
begin
        call convertCategory(category, @categoryID);
        insert into product(NAME, PRICE, QUANTITY, COLOR, DESCRIPTION, CATEGORY) value (name, price, quantity, color, description, @categoryID);
    end;

