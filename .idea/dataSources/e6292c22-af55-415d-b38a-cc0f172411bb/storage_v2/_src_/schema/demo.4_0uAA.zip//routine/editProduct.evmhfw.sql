create
    definer = root@localhost procedure editProduct(IN editId int, IN inputName varchar(50), IN inputPrice float,
                                                   IN inputQuantity int, IN inputColor varchar(50),
                                                   IN inputDescription varchar(100), IN category varchar(50))
begin
        call convertCategory(category, @categoryID);
        update product set name = inputName, price = inputPrice, quantity = inputQuantity, color = inputColor, description = inputDescription, category = @categoryID where id = editId;
    end;

