create
    definer = root@localhost procedure convertCategory(IN input varchar(50), OUT output int)
begin
    select categoryId into output from category where category = input;
end;

