create
    definer = root@localhost procedure selectALLProduct()
begin
    select product.id, product.name, product.price, product.quantity, product.color, product.description,category.category
           from product join category on product.category = category.categoryId;
end;

