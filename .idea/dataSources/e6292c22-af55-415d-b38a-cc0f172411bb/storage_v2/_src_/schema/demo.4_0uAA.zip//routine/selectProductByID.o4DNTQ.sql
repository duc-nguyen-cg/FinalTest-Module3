create
    definer = root@localhost procedure selectProductByID(IN id int)
begin
    select product.id, product.name, product.price, product.quantity, product.color, product.description,category.category
    from product join category on product.category = category.categoryId
    where product.id = id;
end;

